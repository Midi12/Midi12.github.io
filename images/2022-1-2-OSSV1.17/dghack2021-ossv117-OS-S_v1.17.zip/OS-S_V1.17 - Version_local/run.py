#!/usr/bin/env python3
import os
import signal
import subprocess

def proof_of_work():
    try:
        subprocess.check_call(
            ["python3", "pow.py", "ask", "31337"], stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        print("Wrong pow.")
        exit(1)

    # Print banner if pow succeed.
    try:
        subprocess.check_call(
            ['figlet -c "O S - S        v 1.17" | /usr/games/lolcat --animate --duration 5 --seed 19 --force'], shell=True, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        print("OS-S v1.17")

def sig_handler(signum, stack_frame):
    print("")
    print("Temps d'exécution maximum atteint !")
    print("Travaille en local puis valide ici.")
    exit(1)

if __name__ == '__main__':
    signal.signal(signal.SIGALRM, sig_handler) 
    signal.alarm(120)

    proof_of_work()

    choise = input("Voulez-vous utiliser une configuration personnalisée pour le processeur ? [O/N] : ")

    if choise == "O":
        cpu = str(input("Configuration cpu: "))

        import string
        if not all([c in string.ascii_letters + string.digits + "," + "=" + '-' + '.' for c in cpu]):
            print("Caractères non autorisés.")
            exit()

    else:
        cpu = "Westmere"

    argv = ["/usr/bin/timeout", "120",
            "/usr/bin/qemu-system-x86_64",
            "-snapshot",
            "-display", "none",
            "-serial", "stdio",
            "-drive", "format=raw,readonly,index=0,if=floppy,file=os-image.bin",
            "-hdb", "flag_04.txt",
            "-cpu", cpu
            ]

    env = {}
    os.execve(argv[0], argv, env)