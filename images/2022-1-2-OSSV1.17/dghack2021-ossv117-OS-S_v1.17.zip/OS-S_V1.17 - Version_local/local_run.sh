#!/bin/bash

qemu-system-x86_64 \
    -snapshot \
    -drive format=raw,readonly,index=0,if=floppy,file=os-image.bin \
    -hdb flag_04.txt \
    -serial stdio